prompt --workspace/credentials/app_105_push_notifications_credentials_2
begin
--   Manifest
--     CREDENTIAL: App 105 Push Notifications Credentials (2)
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.5'
,p_default_workspace_id=>1389747021320061
,p_default_application_id=>105
,p_default_id_offset=>276116862231484766
,p_default_owner=>'EXT'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(280502266237155222)
,p_name=>'App 105 Push Notifications Credentials (2)'
,p_static_id=>'App_105_Push_Notifications_Credentials_2_'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
