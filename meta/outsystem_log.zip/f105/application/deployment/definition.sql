prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.5'
,p_default_workspace_id=>1389747021320061
,p_default_application_id=>105
,p_default_id_offset=>276116862231484766
,p_default_owner=>'EXT'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(411272088343641595)
);
wwv_flow_imp.component_end;
end;
/
