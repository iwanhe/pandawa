prompt --application/shared_components/automations/outsytems_log
begin
--   Manifest
--     AUTOMATION: OUTSYTEMS LOG
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.5'
,p_default_workspace_id=>1389747021320061
,p_default_application_id=>105
,p_default_id_offset=>276116862231484766
,p_default_owner=>'EXT'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(276708052749953741)
,p_name=>'OUTSYTEMS LOG'
,p_static_id=>'outsytems-log'
,p_trigger_type=>'POLLING'
,p_polling_interval=>'FREQ=MINUTELY;INTERVAL=5'
,p_polling_status=>'ACTIVE'
,p_result_type=>'ALWAYS'
,p_use_local_sync_table=>false
,p_query_type=>'TABLE'
,p_include_rowid_column=>false
,p_commit_each_row=>false
,p_error_handling_type=>'IGNORE'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(276708350295953876)
,p_automation_id=>wwv_flow_imp.id(276708052749953741)
,p_name=>'New Action'
,p_execution_sequence=>10
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    XTD_LOG_OUTSYSTEM_GENERATED;',
'end;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
