prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 105
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.5'
,p_default_workspace_id=>1389747021320061
,p_default_application_id=>105
,p_default_id_offset=>276116862231484766
,p_default_owner=>'EXT'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(411218316599288903)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(410966587767288424)
,p_default_dialog_template=>wwv_flow_imp.id(410974076023288427)
,p_error_template=>wwv_flow_imp.id(410971476925288426)
,p_printer_friendly_template=>wwv_flow_imp.id(410966587767288424)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(410971476925288426)
,p_default_button_template=>wwv_flow_imp.id(411128281601288541)
,p_default_region_template=>wwv_flow_imp.id(411055118074288485)
,p_default_chart_template=>wwv_flow_imp.id(411055118074288485)
,p_default_form_template=>wwv_flow_imp.id(411055118074288485)
,p_default_reportr_template=>wwv_flow_imp.id(411055118074288485)
,p_default_tabform_template=>wwv_flow_imp.id(411055118074288485)
,p_default_wizard_template=>wwv_flow_imp.id(411055118074288485)
,p_default_menur_template=>wwv_flow_imp.id(411067523209288489)
,p_default_listr_template=>wwv_flow_imp.id(411055118074288485)
,p_default_irr_template=>wwv_flow_imp.id(411045320766288482)
,p_default_report_template=>wwv_flow_imp.id(411093350810288508)
,p_default_label_template=>wwv_flow_imp.id(411125778121288532)
,p_default_menu_template=>wwv_flow_imp.id(411129871717288543)
,p_default_calendar_template=>wwv_flow_imp.id(411130023610288553)
,p_default_list_template=>wwv_flow_imp.id(411109671971288521)
,p_default_nav_list_template=>wwv_flow_imp.id(411121525233288526)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(411121525233288526)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(411116090780288523)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(410991319543288458)
,p_default_dialogr_template=>wwv_flow_imp.id(410988531907288457)
,p_default_option_label=>wwv_flow_imp.id(411125778121288532)
,p_default_required_label=>wwv_flow_imp.id(411127104266288533)
,p_default_navbar_list_template=>wwv_flow_imp.id(411115701422288523)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/23.2/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
