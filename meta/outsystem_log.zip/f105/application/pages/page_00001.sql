prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.5'
,p_default_workspace_id=>1389747021320061
,p_default_application_id=>105
,p_default_id_offset=>276116862231484766
,p_default_owner=>'EXT'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'OUTSYTEM LOG'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function toggleDarkMode() {',
'    let body = document.body;',
'    body.classList.toggle("dark-mode");',
'',
'    // Simpan preferensi pengguna di LocalStorage',
'    if (body.classList.contains("dark-mode")) {',
'        localStorage.setItem("theme", "dark");',
'    } else {',
'        localStorage.setItem("theme", "light");',
'    }',
'}',
'',
'// Cek LocalStorage saat halaman dimuat',
'document.addEventListener("DOMContentLoaded", function () {',
'    if (localStorage.getItem("theme") === "dark") {',
'        document.body.classList.add("dark-mode");',
'    }',
'});',
''))
,p_step_template=>wwv_flow_imp.id(410966587767288424)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'CHESAR.BUDIPRAKOSO@LIMAMAIL.NET'
,p_last_upd_yyyymmddhh24miss=>'20250221145624'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(268109218683864617)
,p_plug_name=>'Home'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-Cards--featured t-Cards--block force-fa-lg:t-Cards--displayIcons:t-Cards--stacked:t-Cards--animColorFill'
,p_plug_template=>wwv_flow_imp.id(410988531907288457)
,p_plug_display_sequence=>10
,p_list_id=>wwv_flow_imp.id(276721920473237544)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(411104142100288519)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(411252400657289150)
,p_plug_name=>'OUTSYTEM LOG'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(411021842164288473)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp.component_end;
end;
/
