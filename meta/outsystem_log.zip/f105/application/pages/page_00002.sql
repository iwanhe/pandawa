prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.5'
,p_default_workspace_id=>1389747021320061
,p_default_application_id=>105
,p_default_id_offset=>276116862231484766
,p_default_owner=>'EXT'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'OUTSYTEM LOG VIEW'
,p_alias=>'LOG-VIEW'
,p_step_title=>'OUTSYTEM LOG VIEW'
,p_footer_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<meta http-equiv="refresh" content="300">',
'<script>',
'    document.addEventListener("DOMContentLoaded", function() {',
'        let refreshIndicator = document.createElement("div");',
'        refreshIndicator.innerText = "Refreshing...";',
'        refreshIndicator.style.position = "fixed";',
'        refreshIndicator.style.bottom = "30px";',
'        refreshIndicator.style.right = "30px";',
'        refreshIndicator.style.backgroundColor = "rgba(0,0,0,0.7)";',
'        refreshIndicator.style.color = "white";',
'        refreshIndicator.style.padding = "15px 20px";',
'        refreshIndicator.style.borderRadius = "10px";',
'        refreshIndicator.style.fontSize = "14px";',
'        document.body.appendChild(refreshIndicator);',
'',
'        setTimeout(() => { refreshIndicator.remove(); }, 1000); // Hilang setelah 5 detik',
'    });',
'</script>',
'',
'<meta http-equiv="refresh" content="300">',
'<style>',
'    /* Styling untuk overlay */',
'    .refresh-overlay {',
'        position: fixed;',
'        top: 0;',
'        left: 0;',
'        width: 100%;',
'        height: 100%;',
'        background: rgba(0, 0, 0, 0.5);',
'        display: flex;',
'        justify-content: center;',
'        align-items: center;',
'        z-index: 9999;',
'    }',
'',
'    /* Styling untuk loading spinner */',
'    .spinner {',
'        width: 50px;',
'        height: 50px;',
'        border: 6px solid #fff;',
'        border-top: 6px solid transparent;',
'        border-radius: 50%;',
'        animation: spin 1s linear infinite;',
'    }',
'',
'    @keyframes spin {',
'        0% { transform: rotate(0deg); }',
'        100% { transform: rotate(360deg); }',
'    }',
'</style>',
'',
'<script>',
'    document.addEventListener("DOMContentLoaded", function() {',
'        // Buat elemen overlay',
'        let overlay = document.createElement("div");',
'        overlay.className = "refresh-overlay";',
'',
'        // Buat elemen spinner',
'        let spinner = document.createElement("div");',
'        spinner.className = "spinner";',
'',
'        // Tambahkan spinner ke dalam overlay',
'        overlay.appendChild(spinner);',
'',
'        // Tambahkan overlay ke dalam body',
'        document.body.appendChild(overlay);',
'',
'        // Hapus overlay setelah 5 detik',
'        setTimeout(() => { overlay.remove(); }, 1000);',
'    });',
'</script>',
''))
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(410966587767288424)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'18'
,p_last_updated_by=>'CHESAR.BUDIPRAKOSO@LIMAMAIL.NET'
,p_last_upd_yyyymmddhh24miss=>'20250225112316'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(411255898122300197)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(411067523209288489)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(410951771336288258)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(411129871717288543)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(411256609183300203)
,p_plug_name=>'OUTSYTEM LOG VIEW'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(411045320766288482)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       LOG_DATE,',
'       LOG_TIME,',
'       LOG_CLIENT,',
'       CASE ',
'           WHEN LOG_CLIENT LIKE ''%Connection error%'' THEN ''#FF0000''',
'           ELSE LOG_CLIENT',
'       END AS LOG_CLIENT_BG_COLOR,',
'       CASE ',
'           WHEN LOG_CLIENT LIKE ''%Connection error%'' THEN ''#fff''',
'           ELSE LOG_CLIENT',
'       END AS LOG_CLIENT_TEXT_COLOR,',
'       FILENAME',
'  from XTD_LOG_OUTSYSTEM',
'  ORDER BY LOG_DATE DESC, LOG_TIME DESC;',
''))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_content_disposition=>'ATTACHMENT'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header=>'OUTSYTEM LOG VIEW'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(411256716461300203)
,p_name=>'LOG VIEW'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y_OF_Z'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'CHESAR.BUDIPRAKOSO@LIMAMAIL.NET'
,p_internal_uid=>135139854229815437
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(411257002477300369)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(411257423361300378)
,p_db_column_name=>'LOG_DATE'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Log Date'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(411258181369300380)
,p_db_column_name=>'LOG_CLIENT'
,p_display_order=>4
,p_column_identifier=>'D'
,p_column_label=>'Log Client'
,p_column_html_expression=>'<div style="background-color: #LOG_CLIENT_BG_COLOR#; color: #LOG_CLIENT_TEXT_COLOR#; width: fit-content; flex-wrap: wrap; display: flex; position: relative;">#LOG_CLIENT#</div>'
,p_column_type=>'STRING'
,p_display_text_as=>'WITHOUT_MODIFICATION'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(408771838794356604)
,p_db_column_name=>'LOG_TIME'
,p_display_order=>14
,p_column_identifier=>'E'
,p_column_label=>'Log Time'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_format_mask=>'HH24:MI:SS'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(408771953630356605)
,p_db_column_name=>'FILENAME'
,p_display_order=>24
,p_column_identifier=>'F'
,p_column_label=>'Filename'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(268110208221864627)
,p_db_column_name=>'LOG_CLIENT_BG_COLOR'
,p_display_order=>34
,p_column_identifier=>'H'
,p_column_label=>'Log Client Bg Color'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(268110332584864628)
,p_db_column_name=>'LOG_CLIENT_TEXT_COLOR'
,p_display_order=>44
,p_column_identifier=>'I'
,p_column_label=>'Log Client Text Color'
,p_column_type=>'STRING'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(411259315653319067)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'1351425'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'LOG_DATE:LOG_TIME:LOG_CLIENT'
);
wwv_flow_imp.component_end;
end;
/
