prompt --application/shared_components/security/authentications/authentication
begin
--   Manifest
--     AUTHENTICATION: Authentication
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.5'
,p_default_workspace_id=>30014105435788499543
,p_default_application_id=>216180
,p_default_id_offset=>0
,p_default_owner=>'WKSP_NTIAPPS'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(30039832031447394656)
,p_name=>'Authentication'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'LOGIN_USERS_AUTH'
,p_attribute_05=>'N'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_version_scn=>1
);
wwv_flow_imp.component_end;
end;
/
