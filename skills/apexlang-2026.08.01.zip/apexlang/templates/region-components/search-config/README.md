# Search Config Templates

## Purpose
Canonical guidance for the `search-config` region family, including shared contract loading and supported scenario variants.

## Usage
- Load `search-config._common.md` first to align variable contracts, guardrails, and required inputs.
- Choose a scenario variant matching the requested interaction pattern, data source type, and page composition context.
- Preserve canonical path references and markdown-first conventions when updating workflow or registry links.

## Template Catalog
- `search-config._common.md`
- `search-config.standard.md`

## Maintenance
- Keep this README synchronized with actual files in the directory.
- Update catalogs and usage notes whenever templates are added, removed, or renamed.
- Keep family guidance aligned with page-level standards in memory-bank rules and with scenario coverage in this folder.
