---
name: oracle-db-skills
description: 149 Oracle Database reference guides covering SQL, PL/SQL, performance tuning, security, ORDS, SQLcl, migrations, AI agent patterns, and ORM framework integrations. Load individual skill files on demand for expert guidance on any Oracle topic.
version: 1.0.0
repository: https://github.com/krisrice/oracle-db-skills
---

# Oracle DB Skills

A collection of 149 standalone reference guides for Oracle Database. Each file covers one topic with explanations, practical examples, best practices, and common mistakes.

## How to Use

1. **Find the right skill** using the category routing table below.
2. **Read only the file(s)** relevant to the user's task — do not load all files at once.
3. **Apply the guidance** to answer questions, generate code, or review existing work.

## Category Routing

| User asks about… | Read from |
|------------------|-----------|
| Backup, recovery, RMAN, Data Guard, redo/undo logs, users | `admin/` |
| JDBC, connection pooling, JSON, XML, spatial, full-text, transactions | `appdev/` |
| RAC, CDB/PDB, Exadata, In-Memory, OCI, ATP/ADW | `architecture/` |
| ERD, data modeling, partitioning, tablespaces | `design/` |
| Liquibase, Flyway, online operations, EBR, utPLSQL, git for SQL | `devops/` |
| Advanced Queuing, DBMS_SCHEDULER, materialized views, DBLinks, APEX | `features/` |
| Migrating from PostgreSQL, MySQL, SQL Server, MongoDB, etc. | `migrations/` |
| Alert log, ADR, adrci, space, top SQL, health checks | `monitoring/` |
| ORDS, REST APIs, OAuth2, AutoREST, PL/SQL gateway | `ords/` |
| AWR, ASH, explain plan, indexes, optimizer stats, wait events, memory | `performance/` |
| Packages, cursors, collections, error handling, unit testing, debugging | `plsql/` |
| Privileges, VPD, TDE, encryption, auditing, network security | `security/` |
| SQL patterns, window functions, CTEs, dynamic SQL, injection | `sql-dev/` |
| SQLcl commands, scripting, Liquibase CLI, MCP server, CI/CD | `sqlcl/` |
| AI agent safety, nl-to-sql, intent disambiguation, DML guards | `agent/` |
| ORM integration: Django, SQLAlchemy, Spring JPA, GORM, TypeORM, etc. | `frameworks/` |

## Skills Directory

```
├── admin/          Database administration (backup, recovery, users, redo/undo)
├── agent/          AI agent patterns (safe DML, nl-to-sql, intent disambiguation)
├── appdev/         Application development (JSON, XML, spatial, text, pooling)
├── architecture/   Infrastructure (RAC, Multitenant, Exadata, In-Memory, OCI)
├── containers/     Docker & container deployment
├── design/         Schema design (ERD, modeling, partitioning, tablespaces)
├── devops/         CI/CD and DevOps (migrations, EBR, testing, version control)
├── features/       Oracle features (AQ, Scheduler, MVs, DBLinks, APEX)
├── frameworks/     ORM integrations (Django, SQLAlchemy, Spring, GORM, TypeORM, etc.)
├── migrations/     Migrating from other databases to Oracle
├── monitoring/     Diagnostics (alert log, ADR, health, space, top SQL)
├── ords/           Oracle REST Data Services
├── performance/    Tuning (AWR, ASH, indexes, optimizer, wait events, memory)
├── plsql/          PL/SQL development (packages, cursors, collections, testing)
├── security/       Security (privileges, VPD, TDE, auditing, network)
├── sql-dev/        SQL development (tuning, patterns, dynamic SQL, injection)
└── sqlcl/          SQLcl CLI tool (basics, scripting, Liquibase, MCP server)
```

## Key Starting Points

- **`sqlcl/sqlcl-mcp-server.md`** — connecting AI assistants to Oracle via the SQLcl MCP server
- **`agent/nl-to-sql-patterns.md`** — translating natural language to safe Oracle SQL
- **`agent/destructive-op-guards.md`** — safeguards before running DELETE/DROP/TRUNCATE
- **`migrations/migration-assessment.md`** — start here for any database migration project
- **`performance/explain-plan.md`** — foundation for all SQL performance work
- **`plsql/plsql-package-design.md`** — foundation for PL/SQL architecture questions
- **`devops/schema-migrations.md`** — Liquibase/Flyway with Oracle in CI/CD pipelines
